import myMath

myMath.fibonacci(5)
myMath.penambahan(1, 2)
myMath.pengurangan(3, 2)
myMath.perkalian(2, 3)
myMath.pembagian(6, 2)
myMath.modulus(6, 2)